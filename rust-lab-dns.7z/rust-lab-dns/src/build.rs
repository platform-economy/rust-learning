mod header;
mod label;
mod packet;
mod query;
mod resource_record;
mod response;
mod traits;

pub use traits::Serialize;
